class Block {
    constructor(id) {
        this.id = id;
        this.is_Visible = false;
        if (id != -1) {
            this.is_Visible = true;
        }
    }

    is_Visible() {
        return this.is_Visible;
    }

    get_ID() {
        return this.id;
    }

    set_ID = function(id) {
        if (id == -1) {
            this.is_Visible = false;
        }

        else {
            this.is_Visible = true;
        }

        this.id = id;
    };
}
