
class Cube {
  static TextureAtlasHandler;
  constructor(){
    this.type = 'cube';
    this.color = [1.0,1.0,1.0,1.0];
    this.matrix = new Matrix4();
    this.children = [];
    this.transformations = [];
    this.movedCoordinates = new Matrix4();
    this.textureIndex = -2;
  }

  render(coordSystem) { //take in our parent coordinate system (0,0 if no parent)
    this.matrix.set(coordSystem); //calibrate the coordinate system
    //console.log("Cur coord: ", this.matrix.elements);
    this.movedCoordinates.set(this.matrix); //tell all children to use our coordinate system
    //console.log(this.matrix);
    for (let transformIndex in this.transformations) { //execute our transformations
      let transform = this.transformations[transformIndex];
      let transformationType = transform[0];
        let transformOp = transform[1]
        //console.log("running", transformOp);
        switch(transformationType) {
          case Transform.Scale:
            this.matrix.scale(transformOp[0], transformOp[1], transformOp[2]);
            break;
          case Transform.Rotate: //if it's either a rotate or a translate, update the new coordinate system to
              this.matrix.rotate(transformOp[0], transformOp[1], transformOp[2], transformOp[3]);
              this.movedCoordinates.rotate(transformOp[0], transformOp[1], transformOp[2], transformOp[3]);
              break;
          case Transform.Translate:
              //console.log("before ",this.matrix.elements);
              //console.log(transformOp);
              this.matrix.translate(transformOp[0], transformOp[1], transformOp[2]);
              this.movedCoordinates.translate(transformOp[0], transformOp[1], transformOp[2]);
              //console.log("after ",this.matrix.elements);
              break;
      }
    }
    //console.log(this.matrix);

    var rgba = this.color;
    //var size = this.size;

    //gl.vertexAttrib3f(a_Position, xy[0], xy[1], 0.0);
    gl.uniform4f(u_FragColor, rgba[0], rgba[1], rgba[2], rgba[3]);
    gl.uniformMatrix4fv(u_ModelMatrix, false, this.matrix.elements);
    gl.uniform1i(u_whichTexture, this.textureIndex);
    let UV_X_S = [0,0];
    let UV_Y_S = [0,1];
    let UV_X_E = [1,0];
    let UV_Y_E = [1,1];
    //front broke this lol
    drawTriangle3DUV(mergeArrays([vertexBufferCube[0].elements, vertexBufferCube[1].elements, vertexBufferCube[2].elements]), [UV_X_S,UV_Y_S, UV_X_E,UV_Y_S, UV_X_S,UV_Y_E]);
    drawTriangle3DUV(mergeArrays([vertexBufferCube[2].elements, vertexBufferCube[1].elements, vertexBufferCube[3].elements]), [UV_X_S,UV_Y_E, UV_X_E,UV_Y_S, UV_X_E, UV_Y_E]);
    //right
    drawTriangle3DUV(mergeArrays([vertexBufferCube[4].elements, vertexBufferCube[0].elements, vertexBufferCube[6].elements]), [UV_X_S,UV_Y_S, UV_X_E,UV_Y_S, UV_X_S,UV_Y_E]);
    drawTriangle3DUV(mergeArrays([vertexBufferCube[6].elements, vertexBufferCube[0].elements, vertexBufferCube[2].elements]), [UV_X_S,UV_Y_E, UV_X_E,UV_Y_S, UV_X_E,UV_Y_E]);
    //back
    drawTriangle3DUV(mergeArrays([vertexBufferCube[7].elements, vertexBufferCube[5].elements, vertexBufferCube[6].elements]), [UV_X_S,UV_Y_E, UV_X_S,UV_Y_S, UV_X_E,UV_Y_E]);
    drawTriangle3DUV(mergeArrays([vertexBufferCube[6].elements, vertexBufferCube[5].elements, vertexBufferCube[4].elements]), [UV_X_E,UV_Y_E, UV_X_S,UV_Y_S, UV_X_E,UV_Y_S]);
    //left
    drawTriangle3DUV(mergeArrays([vertexBufferCube[3].elements, vertexBufferCube[1].elements, vertexBufferCube[7].elements]), [UV_X_S,UV_Y_E, UV_X_S,UV_Y_S, UV_X_E,UV_Y_E]);
    drawTriangle3DUV(mergeArrays([vertexBufferCube[7].elements, vertexBufferCube[1].elements, vertexBufferCube[5].elements]), [UV_X_E,UV_Y_E, UV_X_S,UV_Y_S, UV_X_E,UV_Y_S]);
    //bottom
    drawTriangle3DUV(mergeArrays([vertexBufferCube[4].elements, vertexBufferCube[5].elements, vertexBufferCube[0].elements]),  [UV_X_S,UV_Y_S, UV_X_E,UV_Y_S, UV_X_S,UV_Y_E]);
    drawTriangle3DUV(mergeArrays([vertexBufferCube[0].elements, vertexBufferCube[5].elements, vertexBufferCube[1].elements]), [UV_X_S,UV_Y_E, UV_X_E,UV_Y_S, UV_X_E,UV_Y_E]);
    //top
    drawTriangle3DUV(mergeArrays([vertexBufferCube[3].elements, vertexBufferCube[7].elements, vertexBufferCube[2].elements]), [UV_X_E,UV_Y_S, UV_X_E,UV_Y_E, UV_X_S,UV_Y_S]);
    drawTriangle3DUV(mergeArrays([vertexBufferCube[2].elements, vertexBufferCube[7].elements, vertexBufferCube[6].elements]), [UV_X_S,UV_Y_S, UV_X_E,UV_Y_E, UV_X_S,UV_Y_E]);
   
    //drawTriangle3D([0.0, 1.0, 0.0,  1.0, 1.0, 1.0,  1.0, 0.0, 1.0]);
    //drawTriangle3D([0.0, 0.0, 0.0,  1.0, 1.0, 0.0,  1.0, 1.0, 1.0]);

    /*
    gl.uniform4f(u_FragColor, rgba[0]*0.6, rgba[1]*0.6, rgba[2]*0.6, rgba[3]);
    drawTriangle3D([0.0, 1.0, 1.0,  0.0, 1.0, 1.0,  0.0, 0.0, 1.0]);
    drawTriangle3D([0.0, 1.0, 0.0,  1.0, 1.0, 0.0,  0.0, 1.0, 1.0]);

    drawTriangle3D([1.0, 1.0, 0.0,  1.0, 0.0, 1.0,  1.0, 0.0, 0.0]);
    drawTriangle3D([1.0, 1.0, 0.0,  1.0, 1.0, 1.0,  1.0, 0.0, 1.0]);
    
    drawTriangle3D([0.0, 1.0, 0.0,  0.0, 0.0, 1.0,  0.0, 0.0, 0.0]);
    drawTriangle3D([0.0, 1.0, 0.0,  0.0, 1.0, 1.0,  0.0, 0.0, 1.0]);
    
    drawTriangle3D([0.0, 0.0, 1.0,  1.0, 1.0, 1.0,  0.0, 1.0, 1.0]);
    drawTriangle3D([0.0, 0.0, 1.0,  1.0, 1.0, 0.0,  1.0, 1.0, 1.0]);*/

    for (let i = 0; i < this.children.length; i++) { //tell all our children to render, giving them our coordinate system
      var child = this.children[i];
      child.render(this.movedCoordinates);
      //console.log(child);
    }
  }
}
